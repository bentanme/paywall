# Paywall

Ask Ben for setup instructions.

Add: www.nzherald.co.nz/pf/dist/engine/react.js* to your chrome dev exclusion list.
